package com.cybage.bms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookManagementSystemWorkshopSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
