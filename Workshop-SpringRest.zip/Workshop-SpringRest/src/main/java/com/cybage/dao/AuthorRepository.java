package com.cybage.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cybage.model.Author;

public interface AuthorRepository extends JpaRepository<Author, String> {
	Author findByAuthorEmailId(String authorEmailId);
}
