package com.cybage.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cybage.model.Book;
import com.cybage.service.BookService;

@RestController
public class BookController {
	@Autowired
	BookService bookService;

	@GetMapping("/getAllBook")
	public List<Book> getAllBook() {
		List<Book> bookList = bookService.getAllBooks();
		return bookList;
	}

	@PostMapping("/addBook")
	public ResponseEntity<Book> addBook(@RequestBody Book book) {
		bookService.insertBook(book);
		return new ResponseEntity<Book>(HttpStatus.OK);
	}

	@PutMapping("/editBook/{id}")
	public ResponseEntity<Book> editBook(@PathVariable int id, @RequestBody Book book) {
		bookService.findBookById(id);
		bookService.editBook(book);
		return new ResponseEntity<Book>(HttpStatus.OK);
	}

	@DeleteMapping("/deleteBook/{id}")
	public void deleteBook(@PathVariable int id, Model model) {
		bookService.deleteBookById(id);
	}
	@GetMapping("/getBookById/{id}")
	public Book getAllBook(@PathVariable int id) {
		Book book = bookService.findBookById(id);
		return book;
	}

}
