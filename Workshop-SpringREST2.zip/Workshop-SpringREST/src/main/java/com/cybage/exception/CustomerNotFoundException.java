package com.cybage.exception;

@SuppressWarnings("serial")
public class CustomerNotFoundException extends RuntimeException {
	public CustomerNotFoundException(String mesg) {
		super(mesg);
	}

}
