package com.cybage.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cybage.dao.AdminImpl;

import com.cybage.model.Admin;
import com.cybage.service.AdminService;


/**
 * Servlet implementation class AdminLogin
 */
@WebServlet("/Welcome")
public class AdminLogin extends HttpServlet {
	private static final long serialVersionUID = 1L;
	AdminImpl adminDao;
	AdminService service;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    
 public void init() {
        
	 service= new AdminService();
 }
	 
 public void distroy() {
	 try {
    
     }
     catch (Exception e) {
			// TODO: handle exception
		}
}

	
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		try(PrintWriter printWriter=response.getWriter()){
			String email=request.getParameter("email");
			String password=request.getParameter("password");
			Admin admin=service.authenticateAdmin(email, password);
			HttpSession session= request.getSession();
			session.setAttribute("admin", admin);
			RequestDispatcher dispatcher= request.getRequestDispatcher("Welcome.jsp");
			dispatcher.include(request, response);
			
			System.out.println(admin);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
