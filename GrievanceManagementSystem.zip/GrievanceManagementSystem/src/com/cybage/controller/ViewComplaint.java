package com.cybage.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cybage.model.ComplaintDTO;
import com.cybage.model.Department;
import com.cybage.service.AdminService;

/**
 * Servlet implementation class ViewComplaint
 */
@WebServlet("/ViewComplaint")
public class ViewComplaint extends HttpServlet {
	private static final long serialVersionUID = 1L;
	 AdminService service;  
	    /**
	     * @see HttpServlet#HttpServlet()
	     */
	    public ViewComplaint() {
	        super();
	        // TODO Auto-generated constructor stub
	        service= new AdminService();
	    }
		protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			// TODO Auto-generated method stub
			ArrayList<ComplaintDTO> complaints=(ArrayList<ComplaintDTO>) service.complaintList();
			HttpSession session=request.getSession();
			complaints.forEach(i->System.out.println(i));
			session.setAttribute("complaintList",complaints);
			RequestDispatcher dispatcher= request.getRequestDispatcher("viewComplaint.jsp");
			dispatcher.include(request, response);
		}

}
