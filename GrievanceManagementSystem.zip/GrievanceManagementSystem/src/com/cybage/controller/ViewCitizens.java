package com.cybage.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cybage.model.Citizens;
import com.cybage.model.Department;
import com.cybage.service.AdminService;

/**
 * Servlet implementation class ViewCitizens
 */
@WebServlet("/ViewCitizens")
public class ViewCitizens extends HttpServlet {
	private static final long serialVersionUID = 1L;
	 AdminService service;  
	    
	    public ViewCitizens() {
	        super();
	        
	        service= new AdminService();
	    }
		protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			// TODO Auto-generated method stub
			ArrayList<Citizens> citizens=(ArrayList<Citizens>) service.citizensList();
			HttpSession session=request.getSession();
			citizens.forEach(i->System.out.println(i));
			session.setAttribute("citizenList",citizens);
			RequestDispatcher dispatcher= request.getRequestDispatcher("viewCitizen.jsp");
			dispatcher.include(request, response);
		}
}
