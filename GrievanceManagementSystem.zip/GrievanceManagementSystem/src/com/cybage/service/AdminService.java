package com.cybage.service;

import java.sql.SQLException;
import java.util.List;

import com.cybage.dao.AdminImpl;
import com.cybage.model.Admin;
import com.cybage.model.Citizens;
import com.cybage.model.ComplaintDTO;
import com.cybage.model.Department;

public class AdminService {
		AdminImpl adminDao;
		public AdminService() {
			try {
				adminDao=new AdminImpl();
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
				
		}
		public Admin authenticateAdmin(String email,String password) throws SQLException {
			Admin user=adminDao.authenticateAdmin(email, password);
			return user;
		}
		
		public void addDepartment(Department department) {
			adminDao.addDepartment(department);
		}
		public String removeDepartment(String departmentName) {
			System.out.println(departmentName);
			String deptName=adminDao.removeDepartment(departmentName);
			return deptName;
		}
		public List<Department> departmentList(){
			return adminDao.departmentList();
		}
		public List<Citizens> citizensList(){
			return adminDao.citizensList();
		}
		public List<ComplaintDTO> complaintList(){
			return adminDao.complaintList();
		}
	
}
