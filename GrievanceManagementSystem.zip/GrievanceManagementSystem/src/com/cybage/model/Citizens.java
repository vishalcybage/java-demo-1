package com.cybage.model;

public class Citizens 
{
	private int citizenId;
	private String citizenName;
	private String email;
	private String password;
	
public Citizens() {
	// TODO Auto-generated constructor stub
}

public Citizens(int citizenId, String citizenName, String email, String password) {
	super();
	this.citizenId = citizenId;
	this.citizenName = citizenName;
	this.email = email;
	this.password = password;
}

public int getCitizenId() {
	return citizenId;
}

public void setCitizenId(int citizenId) {
	this.citizenId = citizenId;
}

public String getCitizenName() {
	return citizenName;
}

public void setCitizenName(String citizenName) {
	this.citizenName = citizenName;
}

public String getEmail() {
	return email;
}

public void setEmail(String email) {
	this.email = email;
}

public String getPassword() {
	return password;
}

public void setPassword(String password) {
	this.password = password;
}

@Override
public String toString() {
	return "Citizens [citizenId=" + citizenId + ", citizenName=" + citizenName + ", email=" + email + ", password="
			+ password + "]";
}


	
}
