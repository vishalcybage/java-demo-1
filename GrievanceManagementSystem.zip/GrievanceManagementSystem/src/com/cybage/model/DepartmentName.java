package com.cybage.model;

public enum DepartmentName {
	BIRTH_REGISTRATION, DEATHS_REGISTRAION, DRAINAGE, ELECTRICITY, HEALTH,WATER, PROPERTY_TAX, ROAD ;
}
