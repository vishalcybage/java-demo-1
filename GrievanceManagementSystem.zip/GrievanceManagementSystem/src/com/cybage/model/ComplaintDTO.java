package com.cybage.model;

import java.time.LocalDate;

public class ComplaintDTO {

	private int complainId;
	private String citizenName;
	private String departmentName;
	private String complain;
	private LocalDate date;
	private int status;
	public ComplaintDTO(int complainId, String citizenName, String departmentName, String complain, LocalDate date,
			int status) {
		super();
		this.complainId = complainId;
		this.citizenName = citizenName;
		this.departmentName = departmentName;
		this.complain = complain;
		this.date = date;
		this.status = status;
	}
	public ComplaintDTO() {
		// TODO Auto-generated constructor stub
	}
	public int getComplainId() {
		return complainId;
	}
	public void setComplainId(int complainId) {
		this.complainId = complainId;
	}
	public String getCitizenName() {
		return citizenName;
	}
	public void setCitizenName(String citizenName) {
		this.citizenName = citizenName;
	}
	public String getDepartmentName() {
		return departmentName;
	}
	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}
	public String getComplain() {
		return complain;
	}
	public void setComplain(String complain) {
		this.complain = complain;
	}
	public LocalDate getDate() {
		return date;
	}
	public void setDate(LocalDate date) {
		this.date = date;
	}
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	@Override
	public String toString() {
		return "ComplaintDTO [complainId=" + complainId + ", citizenName=" + citizenName + ", departmentName="
				+ departmentName + ", complain=" + complain + ", date=" + date + ", status=" + status + "]";
	}
	
	
}
