package com.cybage.model;

public class Department {
	private int departmentId;
	private DepartmentName departmentName;
	private String email;
	private String password;
	public Department() {
		
	}
	
	public Department(int departmentId, DepartmentName departmentName, String email, String password) {
		this.departmentId = departmentId;
		this.departmentName = departmentName;
		this.email = email;
		this.password = password;
	}

	public Department(DepartmentName departmentName2, String email2, String password2) {
		this.departmentName = departmentName2;
		this.email = email2;
		this.password = password2;
		// TODO Auto-generated constructor stub
	}

	public int getDepartmentId() {
		return departmentId;
	}
	public void setDepartmentId(int departmentId) {
		this.departmentId = departmentId;
	}
	
	public DepartmentName getDepartmentName() {
		return departmentName;
	}

	public void setDepartmentName(DepartmentName departmentName) {
		this.departmentName = departmentName;
	}

	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	@Override
	public String toString() {
		return "Department [departmentId=" + departmentId + ", departmentName=" + departmentName + ", email=" + email
				+  "]";
	}
}
