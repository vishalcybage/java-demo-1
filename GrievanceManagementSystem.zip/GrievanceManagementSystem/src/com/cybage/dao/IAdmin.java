package com.cybage.dao;

import java.sql.SQLException;
import java.util.List;

import com.cybage.model.Admin;
import com.cybage.model.Citizens;
import com.cybage.model.ComplaintDTO;
import com.cybage.model.Department;

public interface IAdmin {
	
	public Admin authenticateAdmin(String email,String password) throws SQLException;
	public void addDepartment(Department department);
	public String removeDepartment(String departmentName);
	public List<Department> departmentList();
	public List<Citizens> citizensList();
	public List<ComplaintDTO> complaintList();

}
