package com.cybage.dao;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import com.cybage.model.Admin;
import com.cybage.model.Citizens;
import com.cybage.model.ComplaintDTO;
import com.cybage.model.Department;
import com.cybage.model.DepartmentName;
import com.cybage.utilities.Utility;

public class AdminImpl implements IAdmin{
	Connection connection;
	PreparedStatement statement;
	
	 public AdminImpl() throws ClassNotFoundException, SQLException {
			// TODO Auto-generated constructor stub
			connection=Utility.fetchConnection();
			
			System.out.println("Inside UserDao");
		}

	@Override
	public Admin authenticateAdmin(String email, String password) throws SQLException {
		// TODO Auto-generated method stub
		statement=connection.prepareStatement("select * from admin where email=? and password=?");
		statement.setString(1, email);
		statement.setString(2, password);
		
		try(ResultSet resultSet= statement.executeQuery()){
			
			if(resultSet.next()) {
				
				return new Admin(resultSet.getInt(1), resultSet.getString(2), resultSet.getString(3), resultSet.getString(4));
			}
		}
		return null;
	}

	@Override
	public void addDepartment(Department department) {
		
			try (PreparedStatement preparedStatement = connection.prepareStatement("insert into department(department_name,email,password) values(?,?,?)");) {
				preparedStatement.setString(1, department.getDepartmentName().toString());
				preparedStatement.setString(2, department.getEmail());
				preparedStatement.setString(3, department.getPassword());;
				int count = preparedStatement.executeUpdate();
				System.out.println(count + " no of rows updated");
			} catch (SQLException e) {
				e.printStackTrace();
			}

		
	}

	@Override
	public String removeDepartment(String departmentName) {
		System.out.println("Service");
		System.out.println(departmentName);
		try (PreparedStatement preparedStatement = connection
				.prepareStatement("delete from department where department_name=?");) {
			preparedStatement.setString(1,departmentName);
			preparedStatement.executeUpdate();
			return  departmentName;
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return null;
	}

	@Override
	public List<Department> departmentList() {
		
		List<Department> departmentList = new ArrayList<>();
		Department department = null;
		try (Statement statement = connection.createStatement();
				ResultSet resultSet = statement.executeQuery("select department_id,department_name,email from department");) {
			while (resultSet.next()) {
				department = new Department();
				department.setDepartmentId(resultSet.getInt(1));
				department.setDepartmentName(DepartmentName.valueOf(resultSet.getString(2)));
				department.setEmail(resultSet.getString(3));
				departmentList.add(department);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return departmentList;
	}

	@Override
	public List<Citizens> citizensList() {
		List<Citizens> citizensList = new ArrayList<>();
		Citizens citizen = null;
		try (Statement statement = connection.createStatement();
				ResultSet resultSet = statement.executeQuery("select citizen_id,citizen_name,email from citizens");) {
			while (resultSet.next()) {
				citizen= new Citizens();
				citizen.setCitizenId(resultSet.getInt(1));
				citizen.setCitizenName(resultSet.getString(2));
				citizen.setEmail(resultSet.getString(3));
				citizensList.add(citizen);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return citizensList;
	}

	@Override
	public List<ComplaintDTO> complaintList() {
		List<ComplaintDTO> complaintList = new ArrayList<>();
		ComplaintDTO complaint = null;
		try (Statement statement = connection.createStatement();
				ResultSet resultSet = statement.executeQuery("select cp.complaint_id,c.citizen_name,d.department_name,cp.complain,cp.complain_date,cp.complain_status from complaint cp inner join citizens c on cp.citizen_id =c.citizen_id  inner join  department d on cp.department_id=d.department_id;");) {
			while (resultSet.next()) {
				complaint= new ComplaintDTO();
				complaint.setComplainId(resultSet.getInt(1));
				complaint.setCitizenName(resultSet.getString(2));
				complaint.setDepartmentName(resultSet.getString(3));
				complaint.setComplain(resultSet.getString(4));
				complaint.setDate(resultSet.getDate(5).toLocalDate());
				complaint.setStatus(resultSet.getInt(6));
				complaintList.add(complaint);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return complaintList;
	}

}
