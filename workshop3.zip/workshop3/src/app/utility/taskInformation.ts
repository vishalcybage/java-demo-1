export interface ITaskInformation {
    task_name: string,
    assigned_date: Date, 
    completion_date: Date, 
    created_by: string, 
    completed_by: string, 
    completion_time: number
}