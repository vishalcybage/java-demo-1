export interface IMovies{
    title:string,
    releaseDate:Date,
    director:string,
    imageUrl:string
}