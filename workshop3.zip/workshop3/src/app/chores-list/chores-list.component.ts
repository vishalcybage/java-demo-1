import { Component, OnInit } from '@angular/core';
import { ITaskInformation } from '../utility/taskInformation';

@Component({
  selector: 'app-chores-list',
  templateUrl: './chores-list.component.html',
  styleUrls: ['./chores-list.component.scss']
})
export class ChoresListComponent implements OnInit {
  yesterdayChores: string[] = ["Diwali Shopping", "Lunch at 01:00PM", "Visiting some close relatives", "Go to temple", "Meet some old buddies", "Return home before 01:00AM"];
  todaysChores: string[] = ["Complete Workshop before 12:30PM", "Attend Meeting at 09:30AM", "Self Study from 01:20PM", "Clearing doubts on W3Schools and Angular.io", "C2C Session", "Log-off at 07:00PM"];
  choresCompleted: string[] = [];
  // "Complete Workshop", "Attend Meeting at 09:30AM", "Self Study from 01:20PM", "Log-off at 07:00PM"
  tomorrowsChores: string[] = ["Attend session at 09:30AM", "Break at 12:20PM", "Self Study till 07:00PM"];

  chores: ITaskInformation[] = [
    {
      task_name: "Workshop 3 on Angular on 10.11.2021",
      assigned_date: new Date(),
      completion_date: new Date(),
      created_by: "Alka Jhanwar",
      completed_by: "Apurv Mahawar",
      completion_time: new Date().getTime()
    },
    {
      task_name: "Session at 12:30PM",
      assigned_date: new Date(),
      completion_date: new Date(),
      created_by: "Vineeta Yemmi",
      completed_by: "Apurv Mahawar",
      completion_time: new Date().getTime()
    },
    {
      task_name: "C2C",
      assigned_date: new Date(),
      completion_date: new Date(),
      created_by: "Robin Marshal",
      completed_by: "Apurv Mahawar",
      completion_time: new Date().getTime()
    },
    {
      task_name: "PEP Talk",
      assigned_date: new Date(),
      completion_date: new Date(),
      created_by: "Arun Nathani",
      completed_by: "Apurv Mahawar",
      completion_time: new Date().getTime()
    }
  ];


  constructor() { }

  ngOnInit(): void {
    this.chores = this.chores.sort((chore1, chore2) => 0 - (chore1.task_name > chore2.task_name ? -1 : 1));
  }
  choresDone(todayChore: string): void {
    this.choresCompleted.push(todayChore);
    this.todaysChores.splice(this.todaysChores.indexOf(todayChore), 1);
  }
  choresDone2(chore:ITaskInformation):void{
    this.choresCompleted.push(chore.task_name);
    this.chores.splice(this.chores.indexOf(chore),1);
  }


}
