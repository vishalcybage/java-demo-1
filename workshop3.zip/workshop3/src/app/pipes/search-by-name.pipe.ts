import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'searchByName'
})
export class SearchByNamePipe implements PipeTransform {

  transform(value: any[], args: string): any {
    if (!value) return null;
    if (!args) return value;

    let search = args.toLowerCase();
    return value.filter(movies => {
      let movieName = movies.title.toLowerCase();
      return movieName.indexOf(search) !== -1;
    });

  }

}
