import { GenerateNickNamePipe } from './generate-nick-name.pipe';

describe('GenerateNickNamePipe', () => {
  it('create an instance', () => {
    const pipe = new GenerateNickNamePipe();
    expect(pipe).toBeTruthy();
  });
});
