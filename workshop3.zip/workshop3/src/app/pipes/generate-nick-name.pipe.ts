import { Pipe, PipeTransform } from '@angular/core';
import { MovieListComponent } from '../movie-list/movie-list.component';

@Pipe({
  name: 'generateNickName'
})
export class GenerateNickNamePipe implements PipeTransform {

  transform(value: string, args: string): string {
    return "Mr. "+value + " - "+ value.substr(0,3).concat(args.substr(-3));
  }

}
