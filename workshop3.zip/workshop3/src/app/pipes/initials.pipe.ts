import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'initials'
})
export class InitialsPipe implements PipeTransform {

  transform(value: string): unknown {
    return value.substr(0,1).concat(value.substr(-1)).toUpperCase();
  }

}
