import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fav-photo',
  templateUrl: './fav-photo.component.html',
  styleUrls: ['./fav-photo.component.scss']
})
export class FavPhotoComponent implements OnInit {
  photos:string[]=["https://www.dqindia.com/wp-content/uploads/2015/11/cybage-723x420.jpg","https://assets.techcircle.in/uploads/article-image/2019/05/images/18608-corporate.jpg"]
  constructor() { }

  ngOnInit(): void {
  }

}
