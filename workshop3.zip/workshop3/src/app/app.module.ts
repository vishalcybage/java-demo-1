import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ChoresListComponent } from './chores-list/chores-list.component';
import { MovieListComponent } from './movie-list/movie-list.component';
import { FavPhotoComponent } from './fav-photo/fav-photo.component';
import { FavLinksComponent } from './fav-links/fav-links.component';
import { HeaderComponent } from './header/header.component';
import { FormsModule } from '@angular/forms';
import { SearchByNamePipe } from './pipes/search-by-name.pipe';
import { GenerateNickNamePipe } from './pipes/generate-nick-name.pipe';
import { InitialsPipe } from './pipes/initials.pipe';

@NgModule({
  declarations: [
    AppComponent,
    ChoresListComponent,
    MovieListComponent,
    FavPhotoComponent,
    FavLinksComponent,
    HeaderComponent,
    SearchByNamePipe,
    GenerateNickNamePipe,
    InitialsPipe
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
