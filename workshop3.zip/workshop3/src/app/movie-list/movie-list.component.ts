import { Component, OnInit } from '@angular/core';
import { IMovies } from '../utility/movies';

@Component({
  selector: 'app-movie-list',
  templateUrl: './movie-list.component.html',
  styleUrls: ['./movie-list.component.scss']
})
export class MovieListComponent implements OnInit {
  moviesList: string[] = ["Venom: Let There Be Carnage (2021)", "Dune (2021)", "Eternals (2021)", "Spider-Man: No Way Home (2021)", "The Matrix Resurrections (2021)", "No Time to Die (2021)"]
  movieImageUrl: string[] = ["https://upload.wikimedia.org/wikipedia/en/a/a7/Venom_Let_There_Be_Carnage_poster.jpg", "https://upload.wikimedia.org/wikipedia/en/8/8e/Dune_%282021_film%29.jpg", "https://upload.wikimedia.org/wikipedia/en/9/9b/Eternals_%28film%29_poster.jpeg", "https://upload.wikimedia.org/wikipedia/en/0/00/Spider-Man_No_Way_Home_poster.jpg", "https://upload.wikimedia.org/wikipedia/en/5/50/The_Matrix_Resurrections.jpg", "https://upload.wikimedia.org/wikipedia/en/f/fe/No_Time_to_Die_poster.jpg"];
  watchedList: string[] = [];
  watchedListUrl: string[] = [];

  searchBy: string = "";
  constructor() { }

  ngOnInit(): void {
    this.movies = this.movies.sort((movie1, movie2) => 0 - (movie1.title > movie2.title ? -1 : 1));
  }

  addToWatchedList(movie: string, url: string): void {
    this.watchedList.push(movie);
    this.watchedListUrl.push(url);
    this.moviesList.splice(this.moviesList.indexOf(movie), 1);
    this.movieImageUrl.splice(this.movieImageUrl.indexOf(url), 1);
  }

  addToWatchedList1(movie:IMovies): void {
    this.watchedList.push(movie.title);
    this.watchedListUrl.push(movie.imageUrl);
    this.movies.splice(this.movies.indexOf(movie),1);
  }

  

  movies: IMovies[] = [{
    title: "Venom: Let There Be Carnage (2021)",
    releaseDate: new Date(),
    director: "Andy Serkis",
    imageUrl: "https://upload.wikimedia.org/wikipedia/en/a/a7/Venom_Let_There_Be_Carnage_poster.jpg"
  }, {
    title: "Dune (2021)",
    releaseDate: new Date(),
    director: "Denis Villeneuve",
    imageUrl: "https://upload.wikimedia.org/wikipedia/en/8/8e/Dune_%282021_film%29.jpg"
  }, {
    title: "Eternals (2021)",
    releaseDate: new Date(),
    director: "Chloe Zhao",
    imageUrl: "https://upload.wikimedia.org/wikipedia/en/9/9b/Eternals_%28film%29_poster.jpeg"
  }, {
    title: "Spider-Man: No Way Home (2021)",
    releaseDate: new Date(),
    director: "Jon Watts",
    imageUrl: "https://upload.wikimedia.org/wikipedia/en/0/00/Spider-Man_No_Way_Home_poster.jpg"
  }, {
    title: "The Matrix Resurrections (2021)",
    releaseDate: new Date(),
    director: "Lana Wachowski",
    imageUrl: "https://upload.wikimedia.org/wikipedia/en/5/50/The_Matrix_Resurrections.jpg"
  }, {
    title: "No Time to Die (2021)",
    releaseDate: new Date(),
    director: "Cary Joji Fukunaga",
    imageUrl: "https://upload.wikimedia.org/wikipedia/en/f/fe/No_Time_to_Die_poster.jpg"
  }];

}
